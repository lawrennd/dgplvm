DGPLVM software
Version 0.06		Thursday 27 Oct 2011 at 09:23

This software implements various constrained GP-LVM models.

Version 0.05
-----------

First release with little documentation.


MATLAB Files
------------

Matlab files associated with the toolbox are:

constraintExpandParamLDANeg.m: Expands a LDANEG constraint model
dgplvmToolboxes.m: Load in the relevant toolboxes for dgplvm.
constraintLogLikeGradientsLDA.m: Returns gradients of loglikelihood
constraintCreate.m: Creates a constraint model from a options struct
constraintLogLikelihoodLDANeg.m: Constraint loglikelihood LDA Neg model
constraintCreateLDA.m: Creates a LDA constraint model from a options struct
constraintExpandParamLDAPos.m: Expands a LDAPOS constraint model
constraintLogLikelihood.m: Wrapper for Constraint loglikelihood
constraintLogLikeGradientsLDAPos.m: Returns loglikegradients for LDAPos constraint
constraintLogLikelihoodLDAPos.m: Returns loglikelihood for LDAPos constraint
constraintCreateLDANeg.m: Creates a LDANEG constraint model from a options struct
constraintExpandParamLDA.m: Expands a LDA constraint model
constraintExpandParam.m: Expands a constraint model
constraintLogLikeGradientsLDANeg.m: Returns gradients of loglikelihood
constraintLogLikelihoodLDA.m: Constraint loglikelihood for LDA model
constraintOptions.m: Return default options for latent constraint.
constraintCreateLDAPos.m: Creates a LDAPOS constraint model from a options struct
constraintLogLikeGradients.m: Wrapper for constraint loglike gradients

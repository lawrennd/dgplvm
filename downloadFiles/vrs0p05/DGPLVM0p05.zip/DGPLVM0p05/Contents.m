% DGPLVM toolbox
% Version 0.05		11-Aug-2010
% Copyright (c) 2010, Neil D. Lawrence
% 
, Neil D. Lawrence
% CONSTRAINTCREATE Creates a constraint model from a options struct
% CONSTRAINTCREATELDA Creates a LDA constraint model from a options struct
% CONSTRAINTCREATELDANEG Creates a LDANEG constraint model from a options struct
% CONSTRAINTCREATELDAPOS Creates a LDAPOS constraint model from a options struct
% CONSTRAINTEXPANDPARAM Expands a constraint model
% CONSTRAINTEXPANDPARAMLDA Expands a LDA constraint model
% CONSTRAINTEXPANDPARAMLDANEG Expands a LDANEG constraint model
% CONSTRAINTEXPANDPARAMLDAPOS Expands a LDAPOS constraint model
% CONSTRAINTLOGLIKEGRADIENTS Wrapper for constraint loglike gradients
% CONSTRAINTLOGLIKEGRADIENTSLDA Returns gradients of loglikelihood
% CONSTRAINTLOGLIKEGRADIENTSLDANEG Returns gradients of loglikelihood
% CONSTRAINTLOGLIKEGRADIENTSLDAPOS Returns loglikegradients for LDAPos constraint
% CONSTRAINTLOGLIKELIHOOD Wrapper for Constraint loglikelihood
% CONSTRAINTLOGLIKELIHOODLDA Constraint loglikelihood for LDA model
% CONSTRAINTLOGLIKELIHOODLDANEG Constraint loglikelihood LDA Neg model
% CONSTRAINTLOGLIKELIHOODLDAPOS Returns loglikelihood for LDAPos constraint
% CONSTRAINTOPTIONS Return default options for latent constraint.
